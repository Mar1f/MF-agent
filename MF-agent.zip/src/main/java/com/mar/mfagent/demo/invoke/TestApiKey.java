package com.mar.mfagent.demo.invoke;
/**
 * @description；
 * @author:mar1
 * @data:2025/04/25
 **/
public interface TestApiKey {

    String API_KEY = "${spring.ai.dashscope.api-key}";
}


