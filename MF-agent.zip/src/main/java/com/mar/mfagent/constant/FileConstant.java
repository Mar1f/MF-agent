package com.mar.mfagent.constant;
/**
 * @description；
 * @author:mar1
 * @data:2025/05/25
 **/


public interface FileConstant {

    /**
     * 文件保存目录
     */
    String FILE_SAVE_DIR = System.getProperty("user.dir") + "/tmp";
}
